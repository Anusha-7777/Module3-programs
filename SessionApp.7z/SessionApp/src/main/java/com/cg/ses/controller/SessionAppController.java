
package com.cg.ses.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ses.Exception.SessionAppException;
import com.cg.ses.bean.SessionApp;
import com.cg.ses.service.SessionService;

@RestController
public class SessionAppController {
@Autowired
SessionService sessionService;
@RequestMapping(value = "/addSession", method = RequestMethod.POST)
public List<SessionApp> addSession(@RequestBody SessionApp ses) throws SessionAppException {
	return sessionService.addSession(ses);
}
@RequestMapping(value = "/getAllDetails")
public List<SessionApp> getAllSessionDetails() throws SessionAppException {
	return  sessionService.getAllSessionDetails();
}
@RequestMapping(value = "/deleteSession/{sid}", method = RequestMethod.DELETE)
public String deleteSession(@PathVariable("sid") int id) throws SessionAppException {
	sessionService.deleteSession(id);
	return  id+" is deleted";
}
@RequestMapping(value = "/updateSession/{sid}/{sduration}/{sfaculty}", method= RequestMethod.PUT) 
public SessionApp updateSession(@PathVariable("sid")int id,@PathVariable("sduration") int durations,@PathVariable("sfaculty") String faculty)throws SessionAppException  
{ 
	  return sessionService.updateSession(id, durations, faculty); 
	  }

}
