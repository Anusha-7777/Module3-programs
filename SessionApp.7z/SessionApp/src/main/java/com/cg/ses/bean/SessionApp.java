package com.cg.ses.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

@Entity
public class SessionApp {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private int durations;
	private String faculty;
	@Pattern(regexp="(VP|HOD)")
	private String modes;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDurations() {
		return durations;
	}
	public void setDurations(int durations) {
		this.durations = durations;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public String getModes() {
		return modes;
	}
	public void setModes(String modes) {
		this.modes = modes;
	}
	 
		
	}

	