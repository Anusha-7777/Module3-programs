package com.cg.ses.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.cg.ses.Exception.SessionAppException;
import com.cg.ses.bean.SessionApp;
import com.cg.ses.dao.SessionDao;

@Service
public class SessionAppServiceImpl implements SessionService {
@Autowired
SessionDao appDao;
	@Override
	public List<SessionApp> addSession(SessionApp ses) throws SessionAppException {
		try {
			
		appDao.save(ses);
		return appDao.findAll();
		}catch(Exception e) {
			throw new SessionAppException(e.getMessage());
		}
	}

	@Override
	public List<SessionApp> getAllSessionDetails() throws SessionAppException {
		
		return appDao.findAll();
	}

	@Override
	public SessionApp updateSession(int id, int durations, String faculty) throws SessionAppException {

		   Optional<SessionApp>optional=appDao.findById(id);
		  
		   if(optional.isPresent())
		   {
		SessionApp ses=appDao.findById(id).get();
		ses.setDurations(durations);
		ses.setFaculty(faculty);
		   
		
		return appDao.save(ses);
		   }
		else
		{

			   throw new SessionAppException("Customer With Id "+id+" does not exist");
		}
	}

	@Override
	public void deleteSession(Integer id) throws SessionAppException {
		appDao.deleteById(id);
		
	}

}
