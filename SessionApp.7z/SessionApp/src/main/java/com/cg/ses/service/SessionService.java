package com.cg.ses.service;

import java.util.List;


import com.cg.ses.Exception.SessionAppException;
import com.cg.ses.bean.SessionApp;

public interface SessionService
{
	List<SessionApp> addSession(SessionApp session) throws SessionAppException;
	List<SessionApp> getAllSessionDetails() throws SessionAppException;
	SessionApp updateSession(int session,int duration,String faculty) throws SessionAppException;
	void deleteSession(Integer id) throws SessionAppException;
	
}
