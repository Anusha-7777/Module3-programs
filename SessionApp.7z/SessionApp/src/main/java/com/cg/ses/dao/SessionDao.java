package com.cg.ses.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ses.bean.SessionApp;



@Repository
public interface SessionDao extends JpaRepository<SessionApp,Integer>  {

}
