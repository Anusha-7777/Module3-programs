package com.cg.ses.Exception;

public class SessionAppException extends Exception
{
	  public SessionAppException()
	     {
	    	 super();
	     }
	     public SessionAppException(String msg)
	     {
	    	 super(msg);
	     }
}
